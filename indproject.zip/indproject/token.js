// var base64=require('base-64')
// app.use(bodyParser.json());

        const jwt=require("jsonwebtoken");
       
         token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MzgsImRpc3BsYXluYW1lIjoic25laGEiLCJpYXQiOjE2Njk3MjQwMjYsImV4cCI6MTY2OTc1MTAyNn0.dMXb5O1K_DhoknupiCWXqVtwdY6x1UlBcTHn8xRY2Jw"
        // console.log(token)
        // payload=token.split(".")[1]
        // console.log(payload)
        //  decoder=base64.decode
        //  console.log(decoder)
        //  e=JSON.parser(decoder)
        //  console.log(e)
        e=jwt.decode(token)
        console.log(e)
        ee=e.displayname
        eee=e.id
        console.log(eee)
        console.log(ee)



